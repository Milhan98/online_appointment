/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage;
import java.sql.*;
/**
 *
 * @author Akthar aki
 */
public class UserDatabase {
    
     Connection con ;

    public UserDatabase(Connection con) {
        this.con = con;
    }
     
    //user login
    public user login(String userid, String password){
        user user=null;
        try{
            String query ="select * from login WHERE userid=? and password=?";
            PreparedStatement pst = this.con.prepareStatement(query);
            pst.setString(1, userid);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            
            if(rs.next()){
                user = new user();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setPassword(rs.getString("password"));
                
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return user;
    }
    
    
    
    
}
